from tkinter import *
import random
import re
from password_gen import check, generate

def open_check_window():
    check_window = Toplevel(window)
    check_window.title("Check Password")
    check_window.geometry("400x200")
    check_window.configure(bg="#2c3e50")

    def check_password():
        password = password_entry.get()
        strength = check(password)
        strength_label.config(text=f"Password Strength: {strength}", fg="white")
        if strength == "Strong":
            strength_label.config(bg="green")
        elif strength == "Medium":
            strength_label.config(bg="orange")
        else:
            strength_label.config(bg="red")

    frame = Frame(check_window, bg="#2c3e50")
    frame.pack(pady=20)

    password_label = Label(frame, text="Enter Password:", font=("Arial", 12), bg="#2c3e50", fg="white")
    password_label.grid(row=0, column=0, pady=10)

    password_entry = Entry(frame, font=("Arial", 12), width=25)
    password_entry.grid(row=0, column=1, pady=10, padx=10)

    check_button = Button(frame, text="Check Strength", command=check_password, font=("Arial", 12), bg="#3498db", fg="white", relief=FLAT)
    check_button.grid(row=1, columnspan=2, pady=10)

    strength_label = Label(frame, text="Password Strength:", font=("Arial", 12), bg="#2c3e50", fg="white")
    strength_label.grid(row=2, columnspan=2, pady=10)

def open_generate_window():
    generate_window = Toplevel(window)
    generate_window.title("Generate Password")
    generate_window.geometry("400x250")
    generate_window.configure(bg="#2c3e50")

    def generate_password():
        try:
            length = int(length_entry.get())
            if length < 8:
                result_label.config(text="Password length must be at least 8 characters.", fg="red")
                copy_button.grid_forget()
            else:
                password = generate(length)
                result_label.config(text=password, fg="white")
                copy_button.grid(row=3, columnspan=2, pady=10)
        except ValueError:
            result_label.config(text="Invalid input. Please enter a number.", fg="red")
            copy_button.grid_forget()

    def copy_to_clipboard():
        generated_password = result_label.cget("text")
        generate_window.clipboard_clear()
        generate_window.clipboard_append(generated_password)
        generate_window.update() 
        copy_button.config(text="Copied!", bg="#2ecc71")
        generate_window.after(2000, lambda: copy_button.config(text="Copy", bg="#3498db"))

    frame = Frame(generate_window, bg="#2c3e50")
    frame.pack(pady=20)

    length_label = Label(frame, text="Enter Length:", font=("Arial", 12), bg="#2c3e50", fg="white")
    length_label.grid(row=0, column=0, pady=10)

    length_entry = Entry(frame, font=("Arial", 12), width=25)
    length_entry.grid(row=0, column=1, pady=10, padx=10)

    generate_button = Button(frame, text="Generate Password", command=generate_password, font=("Arial", 12), bg="#3498db", fg="white", relief=FLAT)
    generate_button.grid(row=1, columnspan=2, pady=10)

    result_label = Label(frame, text="", font=("Arial", 12), bg="#2c3e50", fg="white")
    result_label.grid(row=2, columnspan=2, pady=10)

    copy_button = Button(frame, text="Copy", command=copy_to_clipboard, font=("Arial", 12), bg="#3498db", fg="white", relief=FLAT)
    copy_button.grid_forget()

window = Tk()
window.title("Password Utility")
window.geometry("400x200")
window.configure(bg="#2c3e50")

frame = Frame(window, bg="#2c3e50")
frame.pack(pady=50)

check_button = Button(frame, text="Check Password", command=open_check_window, font=("Arial", 12), bg="#3498db", fg="white", width=20, relief=FLAT)
check_button.grid(row=0, columnspan=2, pady=10)

generate_button = Button(frame, text="Generate Password", command=open_generate_window, font=("Arial", 12), bg="#3498db", fg="white", width=20, relief=FLAT)
generate_button.grid(row=1, columnspan=2, pady=10)

window.mainloop()
