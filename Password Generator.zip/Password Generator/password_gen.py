import random
import re

lowercase_letters = "abcdefghijklmnopqrstuvwxyz"
uppercase_letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
numbers = "0123456789"
symbols = r"!@#$%^&*()_+-=~`/.?><}{[\\]}';:\""

def get_random_lower():
    return random.choice(lowercase_letters)

def get_random_upper():
    return random.choice(uppercase_letters)

def get_random_symbols():
    return random.choice(symbols)

def get_random_numbers():
    return random.choice(numbers)

def generate(length):
    password = ""
    password += get_random_lower()
    password += get_random_numbers()
    password += get_random_upper()
    password += get_random_symbols()

    for _ in range(length - 4):
        char_set = random.choice([lowercase_letters, uppercase_letters, symbols, numbers])
        password += random.choice(char_set)
    return password

def check(password):
    if not password:
        return "Empty password."

    try:
        strong_regex = (
            r"(?=^.{8,}$)"          
            r"(?=.*[a-z])"           
            r"(?=.*[A-Z])"           
            r"(?=.*\d)"              
            r"(?=.*[!@#$%^&*()_+\-=\~`/.?><}{[\]';:\"])"
        )

        medium_regex = (
            r"(?=^.{8,}$)" 
            r"(?=.*[a-z])"           
            r"(?=.*\d)"    
        )

        if re.match(strong_regex, password):
            return "Strong"
        elif re.match(medium_regex, password):
            return "Medium"
        else:
            return "Weak"
    except re.error as e:
        print("Error during regex search:", e) 
        return "An error occurred while checking the password."

